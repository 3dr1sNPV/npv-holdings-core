# TUX GEN — Uncle Ed's v0.2

This is the expanded end-to-end product prototype for **UNCLE ED'S — By Edris Nazparvar** and the TUX GEN Digital Tailoring System.

## Implemented UI/UX

Home / house console; onboarding; Quick/Guided/Bespoke mode choice; body profile; editable measurement database; guided scan workflow; scan quality; front/side/back stages; confidence model; body model; posture/asymmetry visualization; Design Studio; parametric garment preview; fit/proportion engine; Textile Lab; cost planning; Pattern Lab; tailor mode; fitting/version workflow; QC checklist; wardrobe; production stages; certificate; settings/privacy shell; JSON garment export.

## Locked 001 rules

- 001 = highest designation / ONE OF ONE, not first production model.
- 12 cm maximum lapel width.
- 4.5 cm trouser waistband target; 5 cm absolute maximum.
- Structured Boxy Hollywood fit.
- Crossover single-button architecture.
- Straight architectural peak-lapel edge.
- White formal shirt.
- Large black satin butterfly bow tie.
- Aged silver house hardware.
- Deep black 280–320 g/m² wool with subtle green depth.
- Black/deep forest cupro lining with hidden oxblood pathways.
- Nothing militaristic on the surface; purposeful engineering underneath.

## What is genuinely functional now

The UI is stateful during the session, controls update the garment model, measurements are editable, derived measurements update, scan workflow advances, simulated scan changes confidence/source, revisions increment, pattern manifest exports, garment JSON exports, and print views are available.

## The hard limits

The following are intentionally **not faked**:

1. Production-grade phone-only body scanning / 3D reconstruction.
2. Validated anthropometric solver from camera imagery.
3. True physical cloth simulation and production 3D garment drape.
4. A validated 1:1 pattern-drafting solver with real blocks and industrial grading.
5. DXF/AAMA/ASTM production pattern export.
6. Real supplier/fabric inventory, pricing and payment integrations.
7. Cloud authentication, encrypted body-data storage and production privacy infrastructure.
8. Real atelier/tailor network and order fulfillment.

The interfaces and data contracts for these capabilities are already represented so the engines can be plugged in rather than redesigning the product.

## Run

Node.js 18+ recommended:

```bash
npm install
npm run dev
```

## Export

Use the Export button to download the current TUX GEN garment record as JSON. Pattern Lab can export a pattern manifest.
