# EDRIS 001 — SUPPLIER / MAKER PACK

## Required inputs
- Approved technical master
- Approved body measurement sheet
- Approved toile corrections
- Fabric specification and approved swatch
- Black satin facing specification
- Aged-silver hardware specification
- Thread / lining / canvas specification

## Sample gates
A: block/toile — fit only
B: corrected toile — fit + proportion
C: canvas sample — construction + fit
D: golden sample — production reference

## Supplier must return
- sample photos
- construction notes
- deviations
- material substitutions
- labor estimate
- lead time
- unit cost

No substitution becomes approved by silence. Every deviation requires written approval and version update.
