# EDRIS COMMERCE — LIVE CHECKOUT SPEC

## Customer
account, guest checkout, consent, addresses, saved preferences

## Order
order_id, customer_id, line_items, variant, quantity, price_snapshot, tax, shipping, status

## Inventory
SKU, location, available, reserved, allocated, sold, return_hold

## Payments
Use a PCI-compliant external payment provider. Store provider reference, not raw card data.

## Fulfillment
payment confirmed → inventory reserved → pick/pack → provenance attached → shipment created → tracking → delivered

## Returns
return request → eligibility → authorization → inspection → refund/exchange → inventory disposition
