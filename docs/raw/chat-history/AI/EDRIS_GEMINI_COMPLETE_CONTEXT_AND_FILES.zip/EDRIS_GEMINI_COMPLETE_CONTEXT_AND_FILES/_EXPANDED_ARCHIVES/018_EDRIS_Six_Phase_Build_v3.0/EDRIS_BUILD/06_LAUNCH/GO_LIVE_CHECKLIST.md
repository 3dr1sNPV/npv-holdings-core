# EDRIS GO-LIVE CHECKLIST

## Digital
[ ] Responsive QA
[ ] Accessibility pass
[ ] Product data complete
[ ] Search/filter QA
[ ] Build/recommendation QA
[ ] Account QA
[ ] Checkout sandbox QA
[ ] Analytics QA
[ ] Error pages
[ ] Security review

## Physical
[ ] Golden sample approved
[ ] Materials secured
[ ] QC standard signed
[ ] Packaging approved
[ ] Care labels/documentation
[ ] Provenance record
[ ] Inventory received
[ ] Photography complete

## Commercial
[ ] Pricing approved
[ ] Tax setup
[ ] Shipping zones/rates
[ ] Returns policy
[ ] Privacy/consent
[ ] Terms
[ ] Customer support

## Launch sequence
PRIVATE CLIENTS → CONTROLLED ORDER WINDOW → FEEDBACK → CORRECTION → PUBLIC RELEASE
