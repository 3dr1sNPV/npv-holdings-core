# TUX GEN — DATA MODEL v1

## Client
client_id, identity, contact, consent_status, created_at

## Body Profile
profile_id, client_id, measurement_set_version, measurements, posture_notes, date

## Pattern
pattern_id, product_id, client_id, block_version, alteration_version, status

## Fitting
fitting_id, client_id, garment_id, stage, date, notes, corrections, approval

## Garment
garment_id, product_id, serial, material_lot, hardware_set, maker, QC_status

## Provenance
object_id, product_family, materials, craft_record, edition, care, repair, alteration, authenticity, archive

## Rule
Every change creates a version. Never overwrite an approved measurement, pattern, fitting or provenance record.
