# EDRIS Footwear — Retro Technical Sneaker Direction

## New permanent preference
EDRIS casual footwear should include a genuine retro-technical sneaker language inspired by the user's love of adidas Originals-era silhouettes such as the Adi2000 and Niteball II, and the sculptural technical language associated with the Yeezy 700 MNVN.

These are **references for energy and proportion, not templates to copy**.

## THE VECTOR — REVISED CORE SNEAKER

**Role:** EDRIS's signature everyday sneaker.

**Design character:** retro-futurist, chunky, architectural, slightly strange, luxurious but not precious.

### Silhouette
- Full, substantial retro sneaker volume rather than a minimal low-profile trainer.
- Layered upper with controlled panel geometry.
- Strong heel structure.
- Generous padded tongue and collar.
- Sculptural midsole with visible architectural mass.
- Moderately wide forefoot and stable stance.
- Athletic proportions, refined enough to sit beside tailoring.

### EDRIS translation
- Near-black / black / washed charcoal as the primary palette.
- Secondary forest-black, mineral grey and controlled ivory editions.
- Matte technical mesh or woven textile combined with smooth leather/suede overlays.
- One aged-silver or blackened-metal hardware detail only where functionally justified.
- House vertical-incision geometry hidden or subtly integrated into a panel, lace keeper or heel detail.
- Masked Rabbit remains hidden; never make the sneaker look like merchandise.
- No oversized external EDRIS logo.
- Identity must work from silhouette, panel architecture, material contrast and sole geometry.

### Sole
- Thick but disciplined.
- Layered/segmented construction with an Art Deco-like stepped rhythm.
- Black rubber outsole.
- No fake futuristic effects, transparent gimmicks or excessive mechanical detailing.

### Styling
THE VECTOR should work with:
- FOUNDATION TEE
- STRUCTURE SHIRT
- DISTRICT DENIM
- OBSIDIAN
- MONSOON
- AFTERHOURS
- RUIN

It should deliberately create a bridge between EDRIS tailoring and casual clothing.

## Design guardrails
- Do not copy adidas three-stripe placement, proprietary panel layouts, recognizable Yeezy cage/upper geometry, or other signature trade dress.
- Do not turn EDRIS into a sportswear brand.
- Do not make the sneaker excessively clean or minimal.
- Do not use random straps, fake technical vents, unnecessary metal or cyberpunk details.
- The goal is **retro athletic energy civilized through EDRIS architecture**.

## Future sneaker family
If a second sneaker is eventually justified, it should occupy a clearly different role from THE VECTOR rather than becoming a colorway exercise. Possible direction: a more refined court/terrace-derived silhouette, still architectural and dark, but only after THE VECTOR is proven.
