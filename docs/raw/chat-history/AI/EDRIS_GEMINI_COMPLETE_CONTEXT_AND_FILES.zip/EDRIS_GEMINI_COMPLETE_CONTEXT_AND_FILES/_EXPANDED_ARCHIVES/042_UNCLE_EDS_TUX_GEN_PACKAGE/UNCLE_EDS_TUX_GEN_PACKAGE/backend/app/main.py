from fastapi import FastAPI
app=FastAPI(title="UNCLE ED'S TUX GEN API")
@app.get('/')
def home():
 return {"brand":"UNCLE ED'S TUX GEN","status":"online"}
