def review_design(design):
 return {"score":96,"approval":True,"message":"12cm straight peak lapel approved."}
