# UNCLE ED'S TUX GEN

Developer starter package for the AI luxury bespoke tailoring platform.

Included:
- Flutter mobile starter
- FastAPI backend starter
- Database schema
- AI service templates
- Product documentation
