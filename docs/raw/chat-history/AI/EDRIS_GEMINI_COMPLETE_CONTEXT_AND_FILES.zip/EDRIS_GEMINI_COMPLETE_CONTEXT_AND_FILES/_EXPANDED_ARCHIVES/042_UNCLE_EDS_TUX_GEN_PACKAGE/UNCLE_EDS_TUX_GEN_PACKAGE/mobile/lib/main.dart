import 'package:flutter/material.dart';

void main(){runApp(const UncleEdsApp());}

class UncleEdsApp extends StatelessWidget{
 const UncleEdsApp({super.key});
 @override
 Widget build(BuildContext context){
  return MaterialApp(title:"UNCLE ED'S TUX GEN",theme:ThemeData.dark(),home:const Scaffold(body:Center(child:Text("UNCLE ED'S TUX GEN"))));
 }
}
