CREATE TABLE users (id UUID PRIMARY KEY, name TEXT, email TEXT);
CREATE TABLE designs (id UUID PRIMARY KEY, user_id UUID, name TEXT, fabric TEXT, lapel_width FLOAT, hardware TEXT);
