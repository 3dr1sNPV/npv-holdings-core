# API Foundation

POST /design/create
POST /ai/review
POST /body/analyse
POST /orders/create
