# TUX GEN v0.3 — The Digital Atelier

A refined Uncle Ed's UI/UX layer for the TUX GEN digital tailoring system.

## Design direction
- Obsidian / deep forest / ivory / aged silver as the core palette
- Oxblood used as a discovery accent rather than a dominant UI color
- Editorial serif + technical sans/monospace hierarchy
- Atelier / Instrument / Archive visual language
- Restrained motion and drafting-line details
- Mobile responsive and reduced-motion aware

## Run
```bash
npm install
npm run dev
```

## What remains an external engineering boundary
- production-grade phone body scanning / multi-view 3D reconstruction
- physically accurate cloth/garment simulation
- validated production 1:1 pattern solver and DXF/AAMA/ASTM output
- cloud authentication, encrypted persistence, payments, vendors and tailor network

The interface is designed so those engines can be connected without redesigning the user journey.
