const products = [
  {id:'001',name:'ONE OF ONE TUXEDO',category:'FORMAL',tier:'O1',world:'CEREMONY',desc:'Midnight / forest-black wool. One button. 12 cm straight peak. Full canvas.'},
  {id:'COLUMN',name:'THE COLUMN',category:'TAILORING',tier:'CORE / MTM',world:'TAILORING',desc:'Long controlled body, high armhole, straight architectural peak.'},
  {id:'STRUCTURE',name:'THE STRUCTURE SHIRT',category:'SHIRTS',tier:'CORE / SIGNATURE',world:'EVERYDAY',desc:'Concealed placket, architectural collar, controlled body.'},
  {id:'FOUNDATION',name:'THE FOUNDATION TEE',category:'CASUAL',tier:'CORE',world:'EVERYDAY',desc:'Heavy compact cotton, strong shoulder, elongated straight body.'},
  {id:'DENIM',name:'THE DISTRICT DENIM',category:'DENIM',tier:'CORE',world:'EVERYDAY',desc:'Near-black heavy denim, high rise, straight/slightly tapered.'},
  {id:'RUIN',name:'THE RUIN',category:'OUTERWEAR',tier:'CORE',world:'WEATHER',desc:'Below-knee black wool, controlled shoulder, high collar.'},
  {id:'MONUMENT',name:'THE MONUMENT',category:'FOOTWEAR',tier:'CORE',world:'CEREMONY',desc:'Formal wholecut built as the natural partner to 001.'},
  {id:'DOSSIER',name:'THE DOSSIER',category:'LEATHER',tier:'CORE',world:'TRAVEL',desc:'Rigid black architectural briefcase with mechanical lock.'},
  {id:'RABBIT',name:'THE RABBIT',category:'JEWELRY',tier:'ICON',world:'OBJECTS',desc:'Substantial aged sterling silver house icon.'},
  {id:'SEAL',name:'THE SEAL',category:'JEWELRY',tier:'CORE',world:'OBJECTS',desc:'Quiet architectural brooch for tailoring.'},
  {id:'OPERATIVE',name:'THE OPERATIVE',category:'HOROLOGY',tier:'FLAGSHIP',world:'TIME',desc:'40–41 mm automatic instrument watch refined for formal wear.'},
  {id:'RAIN',name:'001 AFTER THE RAIN',category:'FRAGRANCE',tier:'FLAGSHIP',world:'FRAGRANCE',desc:'Cardamom × vetiver × mineral rain. Civilization reclaimed by nature.'},
  {id:'BOW12',name:'THE 12 CM BOW',category:'ACCESSORIES',tier:'ICON',world:'CEREMONY',desc:'Oversized architectural butterfly bow in black silk.'},
  {id:'VAULT',name:'THE VAULT',category:'LEATHER',tier:'CORE',world:'OBJECTS',desc:'Personal-object case for watch, jewelry, fragrance, passport and keys.'}
];
const recommendations={001:['STRUCTURE','BOW12','SEAL','MONUMENT','OPERATIVE','RAIN','VAULT'],COLUMN:['STRUCTURE','SEAL','MONUMENT','DOSSIER','OPERATIVE'],STRUCTURE:['COLUMN','001','DENIM','SEAL','MONUMENT','DOSSIER','RAIN'],RUIN:['STRUCTURE','FOUNDATION','OPERATIVE','VAULT'],RAIN:['001','RUIN','MONSOON','VAULT']};
let cart=[];
function render(list=products){document.querySelector('#catalogue').innerHTML=list.map(p=>`<article class="product" data-id="${p.id}"><div class="product-code">${p.tier}</div><h3>${p.name}</h3><p>${p.desc}</p><small>${p.category} · ${p.world}</small><button onclick="openProduct('${p.id}')">ENTER OBJECT</button></article>`).join('')}
function openProduct(id){const p=products.find(x=>x.id===id);const ids=recommendations[id]||[];const rec=ids.map(x=>products.find(y=>y.id===x)).filter(Boolean);document.querySelector('#modal').innerHTML=`<div class="modal-inner"><button class="close" onclick="closeModal()">×</button><div class="label">${p.tier} / ${p.world}</div><h2>${p.name}</h2><p>${p.desc}</p><p class="rule">DESIGN → ENGINEERING → CRAFT → HOUSE → RELEASE</p><button class="cta" onclick="addToBuild('${p.id}')">ADD TO BUILD</button><h4>THE EDRIS WORLD</h4><div class="rec-grid">${rec.map(r=>`<button onclick="openProduct('${r.id}')">${r.name}</button>`).join('')}</div></div>`;document.querySelector('#modal').classList.add('show')}
function closeModal(){document.querySelector('#modal').classList.remove('show')}
function addToBuild(id){if(!cart.includes(id))cart.push(id);document.querySelector('#buildCount').textContent=cart.length;openBuild()}
function openBuild(){document.querySelector('#build').classList.add('show');document.querySelector('#buildItems').innerHTML=cart.map(id=>{const p=products.find(x=>x.id===id);return `<div><span>${p.name}</span><button onclick="cart=cart.filter(x=>x!=='${id}');openBuild()">REMOVE</button></div>`}).join('')||'<p>Your build is empty.</p>'}
function closeBuild(){document.querySelector('#build').classList.remove('show')}
document.querySelector('#search').addEventListener('input',e=>{const q=e.target.value.toLowerCase();render(products.filter(p=>Object.values(p).join(' ').toLowerCase().includes(q)))});
document.querySelector('#filter').addEventListener('change',e=>{const q=e.target.value;render(q==='ALL'?products:products.filter(p=>p.category===q||p.world===q))});
document.querySelector('#buildButton').onclick=openBuild;
render();
