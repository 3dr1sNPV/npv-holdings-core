# TUX GEN — Uncle Ed's

Portable prototype of the Uncle Ed's Digital Tailoring System.

## Included
- Body profile with confidence-aware measurements
- Guided front/side/back scan workflow
- Scan pipeline: framing → landmarks → segmentation → scale → anthropometrics → posture/asymmetry → confidence → verification
- Scan simulation mode
- 001 Design Studio
- Proportion / finished-measurement engine
- Textile Lab
- Tailor Mode + print specification
- JSON export
- Responsive UI
- Honest production-scan boundary

## Run
Node.js 18+:

    npm install
    npm run dev

## Body scan reality
The scan workflow is implemented, but no claim is made that browser 2D pose alone is tailor-grade. Production requires camera capture, segmentation, calibration, multi-view 3D reconstruction and a validated anthropometric solver. This project provides the integration contract and UI around those components.

## Locked 001 rules
- 001 = highest designation / One of One
- 12 cm maximum lapel
- 4.5 cm waistband target / 5 cm absolute maximum
- Structured Boxy Hollywood fit
- Crossover single-button architecture
- White formal shirt
- Large black satin butterfly bow tie
- Aged silver hardware
- Deep black 280–320 g/m² wool
- Black/deep forest cupro with subtle oxblood pathways
