# EDRIS Product Record Standard v1.0

Every SKU gets: Product ID; family; tier; world; silhouette; intended use; approved materials; hardware; colorways; construction; measurements/spec; tolerances; BOM; supplier/maker; prototype version; golden sample; QC; packaging; care; provenance; photography; copy; pricing; inventory; release status.

Gate: DESIGN → ENGINEERING → CRAFT → HOUSE → RELEASE.
