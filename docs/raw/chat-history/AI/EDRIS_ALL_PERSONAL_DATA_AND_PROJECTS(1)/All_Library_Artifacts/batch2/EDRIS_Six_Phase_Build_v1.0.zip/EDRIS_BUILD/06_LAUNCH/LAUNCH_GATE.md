# EDRIS Launch Gate

## Private launch
Founder/atelier clients → 001 + Foundation system → controlled orders → fitting feedback → production correction → service rehearsal.

## Public launch
Website QA → mobile QA → checkout test → inventory test → transactional email test → shipping test → returns test → privacy/consent review → product photography → final catalogue → analytics → customer support → release.

## First release principle
Launch a small number of exceptional products correctly rather than exposing the entire designed universe before engineering is complete.
