# Digital House Architecture

## Primary navigation
SHOP · TAILORING · OBJECTS · JEWELRY · WATCHES · FRAGRANCE · TRAVEL · HOUSE · ARCHIVE · ATELIER

## Product page modules
1. Object identity
2. Story
3. Materials / construction
4. WEAR WITH
5. COMPLETE THE OBJECT
6. THE EDRIS WORLD
7. NEXT OBJECT
8. Provenance
9. Care / repair
10. Bespoke or acquisition CTA

## Core entities
Product, ProductFamily, Material, Hardware, Client, MeasurementSet, PatternVersion, Order, Fitting, ProvenanceRecord, CareRecord, RepairRecord, ArchiveRecord.

## Technical stack recommendation
Frontend: Next.js + TypeScript. Styling: CSS variables/design tokens. Commerce: headless commerce layer. Data: PostgreSQL. Media: object storage/CDN. Auth: managed identity provider. Payments/shipping/tax: region-appropriate providers. Admin: role-based internal console.

## Non-negotiable UX
No logo wall. No forced cross-sell. Recommendation engine must feel editorial and useful. Mobile-first. Accessibility and performance are release gates.
