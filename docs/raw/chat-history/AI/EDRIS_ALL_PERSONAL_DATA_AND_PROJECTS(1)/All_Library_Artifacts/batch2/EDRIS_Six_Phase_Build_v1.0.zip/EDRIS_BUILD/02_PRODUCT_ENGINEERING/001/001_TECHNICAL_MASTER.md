# EDRIS 001 — ONE OF ONE TUXEDO
## Locked design
Midnight / forest-black luxury wool. Single-breasted, one button. Long Hollywood body. Sculpted Hollywood shoulder. High armhole. Full canvas. Horsehair chest. Structured shoulder and sleeve head. Double-jetted pockets. Double vents. 12 cm STRAIGHT peak lapel. Deep black satin facing.

## Shirt
White fine formal cotton. Formal collar. French cuffs. Concealed/clean front. Aged-silver studs.

## Accessories
Large architectural black butterfly bow. White boutonniere. White pocket square. Aged-silver buttons, cufflinks and studs.

## Trouser
High-rise flat front. Side adjusters. No belt loops. Black satin side stripe. Strong crease. Controlled taper.

## Body measurements supplied
49 cm; 54 cm; 30 cm; 56 cm; 105 cm; 73 cm; 35 cm; 18 cm; 70 cm shoulder-to-wrist.

## Critical engineering rule
Lapel line must read STRAIGHT and architectural, not curved. 12 cm is the maximum approved width.

## Prototype sequence
Draft block → toile → first fitting → correction → second fitting → canvas sample → golden sample → QC → production.
