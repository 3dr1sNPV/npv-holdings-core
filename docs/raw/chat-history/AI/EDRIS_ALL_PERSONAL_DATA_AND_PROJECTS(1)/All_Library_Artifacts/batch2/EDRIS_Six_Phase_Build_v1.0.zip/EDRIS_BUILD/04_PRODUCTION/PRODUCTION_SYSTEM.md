# EDRIS Production System

## Supplier packet
Material specification · color standard · weight/GSM where applicable · construction sheet · hardware drawing · tolerance sheet · packaging sheet · QC checklist · sample approval form.

## Production gates
1 Design approval
2 Material approval
3 Prototype approval
4 Fit/golden sample approval
5 Cost approval
6 Supplier approval
7 Pilot production
8 QC
9 Packaging
10 Release

## QC minimum
Dimensions; seam quality; symmetry; pressing; hardware security; stains/marks; lining; labels; packaging; final visual against golden sample.
