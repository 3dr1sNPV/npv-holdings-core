# TUX GEN — Internal Bespoke Operating System

## Client lifecycle
CONSULTATION → MEASUREMENT → DESIGN → MATERIAL → PATTERN → FITTING → CONSTRUCTION → REVEAL → CARE → REPAIR → ARCHIVE → REORDER

## Core records
Client; MeasurementSet(versioned); PatternBlock(versioned); DesignSpec; MaterialSelection; HardwareSelection; FittingSession; Alteration; ConstructionRecord; GoldenSample; Order; Provenance; Care; Repair; Archive.

## Measurement rule
Never overwrite a historical measurement set. Every change creates a new dated version with source, fitter and notes.

## Privacy
Collect only what is required for the service. Restrict staff access by role. Client records must have retention and deletion policies appropriate to applicable law.
